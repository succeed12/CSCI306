Names: David Young, Eshita Mittal
CSCI306 Section C

Collaborators: None

Notes: 
	Git was very difficult and hard to understand.