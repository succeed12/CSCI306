/**
 * Burner class. 
 *  
 * Authors: David Young, Eshita Mittal
 * 
 * 
 * Purpose: Simulates a burner on a stove
 */

public class Burner {
	public enum Temperature {BLAZING, HOT, WARM, COLD};
	private Temperature userTemp;
	private Setting userSetting;
	private int counter = 0;
	public static final int TIME_DURATION = 2;
	
	public Temperature getUserTemp() {
		return userTemp;
	}
	
	public Burner() {
		super();
		userSetting = Setting.OFF;
		userTemp = Temperature.COLD;
	}
	
	public String display() {
		String information = userSetting + ".....";
		switch(userTemp) {
		case COLD:
			information = information + "cooool";
			break;
		case WARM:
			information = information + "warm";
			break;
		case HOT:
			information = information + "CAREFUL";
			break;
		case BLAZING:
			information = information + "VERY HOT! DON'T TOUCH";
			break;
		}
		return information;
	}
	
	public void plusButton() {
		counter = TIME_DURATION;
		switch (userSetting) {
		case OFF:
			userSetting = Setting.LOW;
			return;
		case LOW:
			userSetting = Setting.MEDIUM;
			return;
		case MEDIUM:
			userSetting = Setting.HIGH;
			return;
		case HIGH:
			return;
		}
	}
	
	public void minusButton() {
		counter = TIME_DURATION;
		switch (userSetting) {
		case LOW:
			userSetting = Setting.OFF;
			return;
		case MEDIUM:
			userSetting = Setting.LOW;
			return;
		case HIGH:
			userSetting = Setting.MEDIUM;
			return;
		case OFF:
			return;
		}
	}
	
	public void updateTemperature() {
		counter -= 1;
		if (counter > 0) {
			return;
		}
		switch (userSetting) {
		case OFF:
			switch (userTemp) {
			case COLD:
				userTemp = Temperature.COLD;
				return;
			case WARM:
				userTemp = Temperature.COLD;
				return;
			case HOT:
				userTemp = Temperature.WARM;
				return;
			case BLAZING:
				userTemp = Temperature.HOT;
				return;
			}
			return;
		case LOW:
			switch (userTemp) {
			case COLD:
				userTemp = Temperature.WARM;
				return;
			case WARM:
				userTemp = Temperature.WARM;
				return;
			case HOT:
				userTemp = Temperature.WARM;
				return;
			case BLAZING:
				userTemp = Temperature.HOT;
				return;
			}
			return;
		case MEDIUM:
			switch (userTemp) {
			case COLD:
				userTemp = Temperature.WARM;
				return;
			case WARM:
				userTemp = Temperature.HOT;
				return;
			case HOT:
				userTemp = Temperature.HOT;
				return;
			case BLAZING:
				userTemp = Temperature.HOT;
				return;
			}
			return;
		case HIGH:
			switch (userTemp) {
			case COLD:
				userTemp = Temperature.WARM;
				return;
			case WARM:
				userTemp = Temperature.HOT;
				return;
			case HOT:
				userTemp = Temperature.BLAZING;
				return;
			case BLAZING:
				userTemp = Temperature.BLAZING;
				return;
			}
			return;
		}
	}

	@Override
	public String toString() {
		String message = "";
		switch(userTemp) {
		case COLD:
			message = "cooool";
			break;
		case WARM:
			message = "warm";
			break;
		case HOT:
			message = "CAREFUL";
			break;
		case BLAZING:
			message = "VERY HOT! DON'T TOUCH";
			break;
		}
		
		return userSetting.toString() + "....." + message;
	}
	
}
