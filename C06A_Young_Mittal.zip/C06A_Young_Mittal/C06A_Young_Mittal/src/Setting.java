/**
 * Setting enumerated type. 
 *  
 * Authors: David Young, Eshita Mittal
 * 
 * 
 * Purpose: Simulates the setting for a Burner
 */

public enum Setting {
	OFF("---"), LOW("--+"), MEDIUM("-++"), HIGH("+++");
	private String value;

	Setting(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "[" + value + "]";
	}
	
	
}
