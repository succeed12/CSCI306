Names: David Young, Eshita Mittal
CSCI306 Section C

Collaborators: None

Notes: 
	Git was very difficult and hard to understand. we had a very hard time understanding how to do commits and 
	showing how each one did what through those commits. 